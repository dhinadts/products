---
name: Bharat Digital Public Infrastructure
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#747686'
  outline-variant: '#c4c5d7'
  surface-tint: '#2151da'
  primary: '#0037b0'
  on-primary: '#ffffff'
  primary-container: '#1d4ed8'
  on-primary-container: '#cad3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#9d4300'
  on-secondary: '#ffffff'
  secondary-container: '#fd761a'
  on-secondary-container: '#5c2400'
  tertiary: '#005022'
  on-tertiary: '#ffffff'
  tertiary-container: '#006b2f'
  on-tertiary-container: '#88ea9a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#0039b5'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb690'
  on-secondary-fixed: '#341100'
  on-secondary-fixed-variant: '#783200'
  tertiary-fixed: '#95f8a7'
  tertiary-fixed-dim: '#79db8d'
  on-tertiary-fixed: '#00210a'
  on-tertiary-fixed-variant: '#005323'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
The brand personality is rooted in the concept of "Modern Governance"—a blend of institutional stability and digital-first efficiency. It targets a broad spectrum of Indian citizens, from tech-savvy urban youth to rural residents requiring high legibility and intuitive paths. The emotional response should be one of immediate trust, reliability, and empowerment.

The design style follows a **Corporate / Modern** approach with a focus on accessibility. It avoids unnecessary decorative elements, prioritizing clarity and functional hierarchy. The interface utilizes generous white space to reduce cognitive load, ensuring that users with varying levels of digital literacy can navigate complex bureaucratic tasks with confidence.

## Colors
The palette is centered around **Bharat Blue**, a deep, stable blue that evokes the authority of public institutions. **Saffron Accent** is used sparingly for primary actions to ensure high visibility and immediate recognition of the next step in a user's journey. 

**Grass Green** is reserved strictly for success states, completed tasks, and safety confirmations. The background architecture uses **Slate Greys** and off-whites to maintain high contrast for text while softening the visual glare on mobile devices. Every color pairing must meet WCAG AA standards for contrast.

## Typography
The system uses **Plus Jakarta Sans** for headlines to provide a modern, approachable feel with its slightly rounded apertures. **Inter** is used for body text and labels to ensure maximum legibility and systematic precision.

To accommodate regional languages which often require more vertical space, the line height is kept generous (minimum 1.5x for body text). For the mobile-first Indian market, headlines scale down aggressively on small screens to prevent awkward word breaks in long Hindi or English terms.

## Layout & Spacing
The design system utilizes a **fluid grid** model based on an 8px base unit. 

- **Mobile:** A 4-column grid with 16px margins and 16px gutters.
- **Tablet:** An 8-column grid with 24px margins and 16px gutters.
- **Desktop:** A 12-column fixed-width grid (max 1280px) centered in the viewport with 24px gutters.

Spacing between functional groups should use `xl` (32px) to ensure users can clearly distinguish between different sections of a form or complaint status. Touch targets for all interactive elements must be at least 48px in height.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**. Surfaces are layered to define hierarchy without clutter:

- **Level 0 (Background):** #F8FAFC (The canvas).
- **Level 1 (Cards/Sheet):** White (#FFFFFF) with a soft, 10% opacity shadow (0px 4px 12px) to separate content from the background.
- **Level 2 (Modals/Popovers):** White (#FFFFFF) with a more defined 15% opacity shadow (0px 8px 24px) to draw immediate focus.

Interactive elements do not use harsh borders; instead, they rely on subtle tonal shifts to indicate focus or active states.

## Shapes
The design system uses a **Rounded** shape language to appear friendly and less institutional. Standard components use a 12px (0.75rem) radius. Large containers and cards use a 16px (1rem) radius. Icons should also follow this geometry, avoiding sharp points in favor of rounded terminals and corners.

## Components
- **Buttons:** Primary buttons use Bharat Blue with white text. CTA buttons (like "Submit Complaint") use Saffron. All buttons have a minimum height of 52px and 12px rounded corners.
- **Input Fields:** Use a 1px Slate-200 border. Labels must always be visible above the field (no floating labels that disappear). 
- **Cards:** Content is grouped in white cards with 16px padding. Status badges (e.g., "Pending," "Resolved") are placed in the top right corner.
- **Language Switcher:** A prominent but clean toggle or dropdown located in the global header or navigation menu, using both the native script (e.g., "हिन्दी") and English for clarity.
- **Iconography:** Use 24px stroke-based icons. Every icon must be accompanied by a text label to assist users who may not recognize abstract symbols.
- **Progress Steppers:** Use a vertical stepper for mobile forms to show the user's journey through a multi-step helpdesk process.